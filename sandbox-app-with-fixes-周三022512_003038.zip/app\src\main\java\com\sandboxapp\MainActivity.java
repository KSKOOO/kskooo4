package com.sandboxapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnSandbox;
    private Button btnFileManager;
    private Button btnSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupClickListeners();
    }

    private void initializeViews() {
        btnSandbox = findViewById(R.id.btnSandbox);
        btnFileManager = findViewById(R.id.btnFileManager);
        btnSettings = findViewById(R.id.btnSettings);
    }

    private void setupClickListeners() {
        // 沙盒功能按钮点击事件
        btnSandbox.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SandboxActivity.class);
            startActivity(intent);
        });

        // 文件管理按钮点击事件
        btnFileManager.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FileManagerActivity.class);
            startActivity(intent);
        });

        // 设置按钮点击事件
        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onBackPressed() {
        // 双击退出应用
        if (System.currentTimeMillis() - lastBackPressTime < 2000) {
            super.onBackPressed();
        } else {
            Toast.makeText(this, "再按一次退出应用", Toast.LENGTH_SHORT).show();
            lastBackPressTime = System.currentTimeMillis();
        }
    }

    private long lastBackPressTime = 0;
}