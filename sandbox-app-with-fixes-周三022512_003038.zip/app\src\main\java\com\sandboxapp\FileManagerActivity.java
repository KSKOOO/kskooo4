package com.sandboxapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FileManagerActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private RecyclerView recyclerViewFiles;
    private LinearLayout emptyLayout;
    private Button btnCreateFile;
    private Button btnRefresh;

    private File sandboxDirectory;
    private FileAdapter fileAdapter;
    private List<File> fileList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_manager);

        initializeViews();
        setupToolbar();
        initializeFileManager();
        setupClickListeners();
        loadFiles();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        recyclerViewFiles = findViewById(R.id.recyclerViewFiles);
        emptyLayout = findViewById(R.id.emptyLayout);
        btnCreateFile = findViewById(R.id.btnCreateFile);
        btnRefresh = findViewById(R.id.btnRefresh);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void initializeFileManager() {
        sandboxDirectory = new File(getExternalFilesDir(null), "sandbox");
        if (!sandboxDirectory.exists()) {
            sandboxDirectory.mkdirs();
        }

        fileList = new ArrayList<>();
        fileAdapter = new FileAdapter(fileList);
        recyclerViewFiles.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewFiles.setAdapter(fileAdapter);
    }

    private void setupClickListeners() {
        btnCreateFile.setOnClickListener(v -> showCreateFileDialog());
        btnRefresh.setOnClickListener(v -> loadFiles());
    }

    private void loadFiles() {
        fileList.clear();
        if (sandboxDirectory.exists() && sandboxDirectory.isDirectory()) {
            File[] files = sandboxDirectory.listFiles();
            if (files != null) {
                fileList.addAll(Arrays.asList(files));
            }
        }

        fileAdapter.notifyDataSetChanged();
        updateEmptyState();
    }

    private void updateEmptyState() {
        if (fileList.isEmpty()) {
            recyclerViewFiles.setVisibility(View.GONE);
            emptyLayout.setVisibility(View.VISIBLE);
        } else {
            recyclerViewFiles.setVisibility(View.VISIBLE);
            emptyLayout.setVisibility(View.GONE);
        }
    }

    private void showCreateFileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("创建文件");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("输入文件名（包含扩展名）");
        builder.setView(input);

        builder.setPositiveButton("创建", (dialog, which) -> {
            String fileName = input.getText().toString().trim();
            if (!fileName.isEmpty()) {
                createFile(fileName);
            } else {
                Toast.makeText(FileManagerActivity.this, "文件名不能为空", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    private void createFile(String fileName) {
        File newFile = new File(sandboxDirectory, fileName);
        try {
            if (newFile.createNewFile()) {
                // 写入一些初始内容
                FileOutputStream fos = new FileOutputStream(newFile);
                String content = "创建时间: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                fos.write(content.getBytes());
                fos.close();
                
                loadFiles();
                Toast.makeText(this, "文件创建成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "文件已存在", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            Toast.makeText(this, "文件创建失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteFile(File file) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("确认删除");
        builder.setMessage("确定要删除文件 " + file.getName() + " 吗？");
        builder.setPositiveButton("删除", (dialog, which) -> {
            if (file.delete()) {
                loadFiles();
                Toast.makeText(FileManagerActivity.this, "文件删除成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(FileManagerActivity.this, "文件删除失败", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 文件适配器
    private class FileAdapter extends RecyclerView.Adapter<FileAdapter.FileViewHolder> {

        private List<File> files;

        public FileAdapter(List<File> files) {
            this.files = files;
        }

        @NonNull
        @Override
        public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_file, parent, false);
            return new FileViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
            File file = files.get(position);
            holder.bind(file);
        }

        @Override
        public int getItemCount() {
            return files.size();
        }

        class FileViewHolder extends RecyclerView.ViewHolder {
            private TextView tvFileName;
            private TextView tvFileInfo;
            private LinearLayout fileItemLayout;

            public FileViewHolder(@NonNull View itemView) {
                super(itemView);
                tvFileName = itemView.findViewById(R.id.tvFileName);
                tvFileInfo = itemView.findViewById(R.id.tvFileInfo);
                fileItemLayout = itemView.findViewById(R.id.fileItemLayout);
            }

            public void bind(File file) {
                tvFileName.setText(file.getName());
                
                String info = "大小: " + formatFileSize(file.length()) + " | " +
                             "修改时间: " + new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date(file.lastModified()));
                tvFileInfo.setText(info);

                fileItemLayout.setOnClickListener(v -> {
                    Toast.makeText(FileManagerActivity.this, "点击文件: " + file.getName(), Toast.LENGTH_SHORT).show();
                });

                fileItemLayout.setOnLongClickListener(v -> {
                    deleteFile(file);
                    return true;
                });
            }

            private String formatFileSize(long size) {
                if (size < 1024) {
                    return size + " B";
                } else if (size < 1024 * 1024) {
                    return String.format(Locale.getDefault(), "%.1f KB", size / 1024.0);
                } else {
                    return String.format(Locale.getDefault(), "%.1f MB", size / (1024.0 * 1024.0));
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFiles();
    }
}