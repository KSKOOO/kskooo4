package com.sandboxapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.File;
import java.text.DecimalFormat;

public class SettingsActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private RadioGroup radioGroupTheme;
    private RadioButton radioLight;
    private RadioButton radioDark;
    private Switch switchAutoClear;
    private Switch switchEncryption;
    private Button btnSaveSettings;
    private TextView tvAppVersion;
    private TextView tvAppSize;

    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "SandboxAppPrefs";
    private static final String KEY_THEME = "theme";
    private static final String KEY_AUTO_CLEAR = "auto_clear";
    private static final String KEY_ENCRYPTION = "encryption";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        initializeViews();
        setupToolbar();
        initializePreferences();
        setupClickListeners();
        loadCurrentSettings();
        updateAppInfo();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        radioGroupTheme = findViewById(R.id.radioGroupTheme);
        radioLight = findViewById(R.id.radioLight);
        radioDark = findViewById(R.id.radioDark);
        switchAutoClear = findViewById(R.id.switchAutoClear);
        switchEncryption = findViewById(R.id.switchEncryption);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);
        tvAppVersion = findViewById(R.id.tvAppVersion);
        tvAppSize = findViewById(R.id.tvAppSize);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void initializePreferences() {
        // 设置默认值
        if (!sharedPreferences.contains(KEY_THEME)) {
            sharedPreferences.edit().putString(KEY_THEME, "light").apply();
        }
        if (!sharedPreferences.contains(KEY_AUTO_CLEAR)) {
            sharedPreferences.edit().putBoolean(KEY_AUTO_CLEAR, false).apply();
        }
        if (!sharedPreferences.contains(KEY_ENCRYPTION)) {
            sharedPreferences.edit().putBoolean(KEY_ENCRYPTION, false).apply();
        }
    }

    private void setupClickListeners() {
        btnSaveSettings.setOnClickListener(v -> saveSettings());
    }

    private void loadCurrentSettings() {
        String theme = sharedPreferences.getString(KEY_THEME, "light");
        boolean autoClear = sharedPreferences.getBoolean(KEY_AUTO_CLEAR, false);
        boolean encryption = sharedPreferences.getBoolean(KEY_ENCRYPTION, false);

        if ("dark".equals(theme)) {
            radioDark.setChecked(true);
        } else {
            radioLight.setChecked(true);
        }

        switchAutoClear.setChecked(autoClear);
        switchEncryption.setChecked(encryption);
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // 保存主题设置
        if (radioDark.isChecked()) {
            editor.putString(KEY_THEME, "dark");
        } else {
            editor.putString(KEY_THEME, "light");
        }

        // 保存其他设置
        editor.putBoolean(KEY_AUTO_CLEAR, switchAutoClear.isChecked());
        editor.putBoolean(KEY_ENCRYPTION, switchEncryption.isChecked());

        if (editor.commit()) {
            Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
            // 应用主题变化
            applyThemeChanges();
        } else {
            Toast.makeText(this, "保存失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyThemeChanges() {
        // 这里可以添加主题切换逻辑
        // 注意：实际应用中需要重启Activity或使用其他方式应用主题
        Toast.makeText(this, "主题设置将在下次启动时生效", Toast.LENGTH_SHORT).show();
    }

    private void updateAppInfo() {
        tvAppVersion.setText("版本: 1.0.0");
        
        // 计算沙盒数据大小
        File sandboxDirectory = new File(getExternalFilesDir(null), "sandbox");
        long size = getFolderSize(sandboxDirectory);
        tvAppSize.setText("沙盒数据大小: " + formatFileSize(size));
    }

    private long getFolderSize(File folder) {
        long length = 0;
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        length += file.length();
                    } else {
                        length += getFolderSize(file);
                    }
                }
            }
        }
        return length;
    }

    private String formatFileSize(long size) {
        if (size <= 0) return "0 B";
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAppInfo();
    }
}