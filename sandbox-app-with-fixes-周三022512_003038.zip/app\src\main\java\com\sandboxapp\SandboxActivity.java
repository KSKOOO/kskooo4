package com.sandboxapp;

import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SandboxActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView tvStatus;
    private TextView tvSandboxInfo;
    private Button btnStartSandbox;
    private Button btnStopSandbox;
    private Button btnClearSandbox;

    private boolean isSandboxRunning = false;
    private File sandboxDirectory;
    private SimpleDateFormat dateFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sandbox);

        initializeViews();
        setupToolbar();
        initializeSandbox();
        setupClickListeners();
        updateUI();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        tvStatus = findViewById(R.id.tvStatus);
        tvSandboxInfo = findViewById(R.id.tvSandboxInfo);
        btnStartSandbox = findViewById(R.id.btnStartSandbox);
        btnStopSandbox = findViewById(R.id.btnStopSandbox);
        btnClearSandbox = findViewById(R.id.btnClearSandbox);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void initializeSandbox() {
        // 创建沙盒目录
        sandboxDirectory = new File(getExternalFilesDir(null), "sandbox");
        if (!sandboxDirectory.exists()) {
            sandboxDirectory.mkdirs();
        }
    }

    private void setupClickListeners() {
        btnStartSandbox.setOnClickListener(v -> startSandbox());
        btnStopSandbox.setOnClickListener(v -> stopSandbox());
        btnClearSandbox.setOnClickListener(v -> clearSandboxData());
    }

    private void startSandbox() {
        if (!isSandboxRunning) {
            isSandboxRunning = true;
            updateUI();
            Toast.makeText(this, "沙盒环境已启动", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopSandbox() {
        if (isSandboxRunning) {
            isSandboxRunning = false;
            updateUI();
            Toast.makeText(this, "沙盒环境已停止", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearSandboxData() {
        if (sandboxDirectory.exists()) {
            deleteRecursive(sandboxDirectory);
            sandboxDirectory.mkdirs();
            updateUI();
            Toast.makeText(this, "沙盒数据已清空", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] files = fileOrDirectory.listFiles();
            if (files != null) {
                for (File child : files) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDirectory.delete();
    }

    private void updateUI() {
        if (isSandboxRunning) {
            tvStatus.setText(getString(R.string.sandbox_running));
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            btnStartSandbox.setEnabled(false);
            btnStopSandbox.setEnabled(true);
            
            // 更新沙盒信息
            String info = "沙盒状态: 运行中\n" +
                         "启动时间: " + dateFormat.format(new Date()) + "\n" +
                         "沙盒目录: " + sandboxDirectory.getAbsolutePath() + "\n" +
                         "文件数量: " + getFileCount(sandboxDirectory) + " 个";
            tvSandboxInfo.setText(info);
        } else {
            tvStatus.setText(getString(R.string.sandbox_stopped));
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            btnStartSandbox.setEnabled(true);
            btnStopSandbox.setEnabled(false);
            
            String info = "沙盒状态: 已停止\n" +
                         "沙盒目录: " + sandboxDirectory.getAbsolutePath() + "\n" +
                         "文件数量: " + getFileCount(sandboxDirectory) + " 个";
            tvSandboxInfo.setText(info);
        }
    }

    private int getFileCount(File directory) {
        if (!directory.exists() || !directory.isDirectory()) {
            return 0;
        }
        File[] files = directory.listFiles();
        return files != null ? files.length : 0;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}