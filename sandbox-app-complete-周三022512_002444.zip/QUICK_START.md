# 🚀 GitHub Actions 自动构建APK - 快速开始

## 🎯 一键完成APK构建和分发

你的Android项目已经完全配置好了GitHub Actions自动构建！只需要几个简单步骤就能获得可安装的APK文件。

---

## 📋 快速开始 (3步完成)

### 第1步：上传代码到GitHub

双击运行：`upload_to_github.bat`

这个脚本会：
- ✅ 初始化Git仓库
- ✅ 配置远程仓库地址
- ✅ 提交所有项目文件
- ✅ 推送到GitHub

### 第2步：等待自动构建

代码推送后，GitHub会自动开始构建：
- 🏗️ **构建时间**: 5-15分钟
- 📍 **监控地址**: 你的GitHub仓库 → Actions标签
- 📱 **生成文件**: Debug APK + Release APK
- 🔧 **构建环境**: Ubuntu Linux (已修复Windows兼容性问题)

### 第3步：下载APK

构建完成后：
- 进入GitHub仓库的Actions页面
- 点击最新的构建任务
- 在 "Artifacts" 部分下载APK

---

## 🎛️ 两种构建模式

### 🔄 自动构建 (推荐)

**触发条件**：
- 代码推送到 `main` 分支
- 创建 Pull Request
- 手动触发

**生成文件**：
```
📦 debug-apk/
└── app-debug.apk          # 调试版本 (30天保存)

📦 release-apk/
└── app-release.apk        # 发布版本 (90天保存)

📦 lint-report/
└── lint-results-debug.html # 代码检查报告
```

### 🏷️ 发布构建 (版本发布)

**触发方式**：双击运行 `release_app.bat`

**功能特性**：
- 🎯 创建版本标签 (v1.0.0, v1.0.1-beta等)
- 🔐 自动生成数字签名
- 📢 创建GitHub Release页面
- 📱 永久保存APK文件

**版本号格式**：
```
✅ 正确格式: 1.0.0, 2.1.3, 1.0.0-beta, 1.0.0-rc1
❌ 错误格式: v1.0, 1.0, 1.0.0.0
```

---

## 🛠️ 可用工具脚本

### 1. 📤 `upload_to_github.bat`
**功能**: 一键上传项目到GitHub
```bash
双击运行 → 输入GitHub用户名 → 输入仓库名 → 自动上传
```

### 2. 🏷️ `release_app.bat` 
**功能**: 创建版本发布
```bash
双击运行 → 输入版本号 → 确认发布 → 自动构建
```

### 3. 🔧 `build_apk_complete.bat`
**功能**: 构建工具和帮助信息
```bash
双击运行 → 选择构建方式 → 获取详细指导
```

---

## 📊 构建配置详解

### 🎯 GitHub Actions工作流

你的项目包含两个工作流文件：

#### 1. 📱 `build-apk.yml` - 日常构建
```yaml
触发: push, pull_request, manual
产物: debug.apk + release.apk
保存: 30-90天
用途: 开发测试、CI/CD
```

#### 2. 🏷️ `release-apk.yml` - 版本发布
```yaml
触发: git tag (v*)
产物: 签名的release.apk
保存: 永久 (GitHub Releases)
用途: 版本分发、用户下载
```

### ⚡ 构建优化特性

- 🚀 **并行构建**: Debug和Release同时构建
- 💾 **智能缓存**: Gradle依赖缓存加速
- 🔍 **代码检查**: 自动Lint检查
- 📋 **构建摘要**: 生成详细的构建报告
- 🎨 **美化输出**: Emoji表情和彩色输出

---

## 🔧 故障排除

### ❌ 常见问题

#### 1. 推送失败
```
问题: 推送代码到GitHub失败
解决: 
- 检查网络连接
- 确认GitHub仓库存在
- 检查用户名和仓库名
```

#### 2. 构建失败
```
问题: GitHub Actions构建报错
解决:
- 查看Actions页面的详细日志
- 检查build.gradle配置
- 确认依赖版本兼容性
```

#### 3. 下载失败
```
问题: APK文件下载超时
解决:
- 使用浏览器直接下载
- 检查网络连接
- 尝试不同的下载链接
```

### 🔍 调试命令

```bash
# 查看Git状态
git status

# 查看远程仓库
git remote -v

# 查看构建历史
git log --oneline

# 强制推送
git push -f origin main
```

---

## 📱 使用构建的APK

### 📲 安装Debug APK
```bash
# 使用ADB安装
adb install app-debug.apk

# 或直接在手机上安装
# 设置 → 安全 → 允许未知来源
```

### 🌐 分发APK给用户

**方法1: GitHub Releases (推荐)**
- 用户直接下载永久保存的APK
- 提供版本说明和更新日志

**方法2: 分发平台**
- 蒲公英、fir.im等平台
- 支持二维码扫码下载

**方法3: 应用商店**
- Google Play Store
- 华为应用市场
- 小米应用商店等

---

## 🎯 实用技巧

### 💡 最佳实践

1. **版本管理**
   ```
   v1.0.0    - 首个正式版本
   v1.0.1    - 修复版本
   v1.1.0    - 功能更新
   v1.0.0-beta - 测试版本
   v2.0.0    - 重大更新
   ```

2. **构建策略**
   ```
   开发阶段: 使用自动构建 (push触发)
   测试阶段: 下载debug APK测试
   发布阶段: 使用版本发布 (tag触发)
   ```

3. **权限设置**
   ```
   GitHub仓库 → Settings → Actions
   ✅ Enable Actions
   ✅ Allow Actions permissions
   ```

### 🚀 高级功能

1. **自动测试**
   ```yaml
   # 可以添加单元测试
   - name: Run Tests
     run: ./gradlew test
   ```

2. **多渠道打包**
   ```yaml
   # 支持构建不同渠道的APK
   - name: Build Flavors
     run: ./gradlew assembleProductionRelease
   ```

3. **通知集成**
   ```yaml
   # 构建完成后发送通知
   - name: Notify
     uses: 8398a7/action-slack@v3
   ```

---

## 📞 获取帮助

如果遇到问题：

1. **查看文档**: `GITHUB_ACTIONS_GUIDE.md` - 详细配置指南
2. **检查日志**: GitHub仓库 → Actions → 查看构建日志
3. **重新构建**: Actions → Run workflow → 手动触发
4. **清理缓存**: Actions → 管理GitHub Actions缓存

---

## 🎉 开始使用

现在你已经有了一个完整的Android项目自动化构建系统！

**立即开始**：
1. 双击 `upload_to_github.bat` 上传项目
2. 等待自动构建完成
3. 下载你的第一个APK文件

**后续开发**：
- 修改代码后，推送即可自动构建
- 需要发布版本时，使用 `release_app.bat`
- 所有构建历史都会保存在GitHub中

🚀 **享受无障碍的APK自动化构建体验！**